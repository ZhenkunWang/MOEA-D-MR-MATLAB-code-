% pareto.m
% 
% The Matlab source codes to generate the PF and the PS of the test
%   instances for CEC 2009 Multiobjective Optimization Competition.
% 
% Usage: [pf, ps] = pareto(problem_name, no_of_points, variable_dim)
% 
% Please refer to the report for more information.
% 
% History:
%   v1 Sept.08 2008

function [pf, ps] = true_pareto(name, no, dim)

    if nargin<3, dim = 3; end
    if nargin<2, no  = 500; end
    switch name
        case {'F1'}
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = repmat((2:dim)',[1,no])/dim-0.55;         
            pf          = zeros(2,no);
            pf(1,:)     = 1-cos(pi*ps(1,:)/2);
            pf(2,:)     = 10-10*sin(pi*ps(1,:)/2);
        case {'F2'}
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = repmat((2:dim)',[1,no])/dim-0.55;         
            pf(1,1:round(0.5*no)) = linspace(0,0.05,round(0.5*no));
            pf(1,(round(0.5*no)+1):no) = linspace(0.05,1,no-round(0.5*no));
            pf(2,1:round(0.5*no)) = 1-19*pf(1,1:round(0.5*no));
            pf(2,(round(0.5*no)+1):no) = 1/19-pf(1,(round(0.5*no)+1):no)/19;
        case {'F3'}
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = 0.5*repmat((2:dim)',[1,no])/dim;         
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);   
            pf(2,1:round(0.5*no)) = 1-0.5*(2*ps(1,1:round(0.5*no))).^4;
            pf(2,(round(0.5*no)+1):no) = 0.5*(2*(1-ps(1,(round(0.5*no)+1):no))).^4;        
        case {'F4','F5'}
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-sqrt(pf(1,:));
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = sin(0.5*pi*repmat(ps(1,:),[dim-1,1]));
        case {'F6','F7'}
            pf          = zeros(2,no);
            pf(1,:)     = linspace(0,1,no);
            pf(2,:)     = 1-sqrt(pf(1,:));
            ps          = zeros(dim,no);
            ps(1,:)     = linspace(0,1,no);
            ps(2:dim,:) = repmat(ps(1,:),[dim-1,1]).^(0.5+1.5*(repmat((0:1:(dim-2))',[1,no]))/(dim-2.0));
         case {'F8'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = 1-ps(1,:).*ps(2,:);
            pf(2,:)     = 1-ps(1,:).*(1-ps(2,:));
            pf(3,:)     = ps(1,:);   
            clear s t;
         case {'F9'}
            num         = floor(sqrt(no));
            no          = num*num;
            [s,t]       = meshgrid(linspace(0,1,num),linspace(0,1,num));
            ps          = zeros(dim,no);
            ps(1,:)     = reshape(s,[1,no]);
            ps(2,:)     = reshape(t,[1,no]);            
            ps(3:dim,:) = repmat(ps(2,:),[dim-2,1]).*repmat(ps(1,:),[dim-2,1]);             
            pf          = zeros(3,no);
            pf(1,:)     = 1-cos(0.5*pi*ps(1,:)).*cos(0.5*pi*ps(2,:));
            pf(2,:)     = 1-cos(0.5*pi*ps(1,:)).*sin(0.5*pi*ps(2,:));
            pf(3,:)     = 1-sin(0.5*pi*ps(1,:));   
            clear s t;       
    end
end
