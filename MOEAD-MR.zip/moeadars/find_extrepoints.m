function [extrpos,extrpoints]=find_extrepoints(v)
[objdim,N]=size(v);
extrpoints=zeros(objdim,objdim); extrpos=zeros(1,objdim);
initindex=1:N;
candv=[v;initindex];
for i=1:objdim
% [~,pos]=sort(v(i,:),2);
% sortv=v(pos,:);
% new = sortrows(old', n)' 
candv=-(sortrows(-candv',i))';
findextreme=0;
B=candv(1:objdim,:);
N=size(B,2);
% candextreme=1;
while findextreme==0
    dominated=0;
      j=1;
  while j<N
      j=j+1;
      C=B(:,1)-B(:,j);
      if all(C>=0)&&any(C~=0)
        dominated=1;
        B(:,1)=[];
        candv(:,1)=[];
        N=N-1;
        break;
      elseif all(C<=0)
        B(:,j)=[];
        candv(:,j)=[];
        N=N-1;
        j=j-1;
      end 
  end
  if dominated==0||N==1
     findextreme=1;
     extrpoints(:,i)=candv(1:objdim,1);
     extrpos(i)=candv(objdim+1,1);
  end
end
end


end