function params = loadparams(testname,methodname,varargin)
%LOADPARAMS Load the parameter settings from external file.
% file format
%   Detailed explanation goes here
    % set the default!!
    % General parameters  
  %useperT=1; %weather to use the proportion of population size or a given number as the neighborhoond size, 1 for proportion
  params = get_structure('parameter');
  % General Setting for MOEA/D
  params.seed = 177; % random seed.
  params.dmethod = 'te'; % decomposition method of choice.
  params.F = 0.5; % the F rate in DE. %%%%params.F = [0.8 0.6 0.5 ];
  params.CR = 1; % the CR rate in DE. %%%%params.CR = [0.2 0.9 1.0 ];
  params.neighbormating = 0.8; % percentage to update the neighbour or the whole population
  params.updatesize = 2; % the maximum updation number.
  params.globupdate = 0;
  params.genevolve = 0;
  params.NLsize = 0;
  % R-MOEA/D specific setting.
  params.dynamic = 0; % weather to use R-MOEA/D or a normal MOEA/D, 1 for R-MOEA/D
  params.selportion =2.5; % the selection percentage of in R-MOEA/D
  params.decayrate = 0.95; % the decay rate in R-MOEA/D˥����
  % set for the default for a specific problem here.
  switch lower(testname)
    case {'zdt1','zdt2','zdt3'}
      xobj=30;
      params.evaluation=50000;
      params.H=99;
      params.popsize = 100;
      params.Tm = 10;
      params.Tr = 10;
      %niche = ceil(perTr*params.popsize);
    case {'zdt4','zdt6'}
      xobj=10;
      params.evaluation=50000;
      params.H=99;            
      params.popsize = 100;
      params.Tm = 10;
      params.Tr = 10;
    case {'dtlz1','dtlz2','dtlz3','dtlz4','dtlz5','dtlz6','dtlz7'}
      xobj=10;
      params.evaluation=100000;
      params.H=23;           
      params.popsize = 300;
      params.Tm = 60;
      params.Tr = 60;
      %niche = ceil(perTr*params.popsize);
    case {'wfg1','wfg2','wfg3','wfg4','wfg5','wfg6','wfg7','wfg8','wfg9'}
      xobj=24;
      params.evaluation=40000;
      params.H=23;
      params.popsize = 100;
      params.Tm = 10;
      params.Tr = 10;
      %niche = ceil(perTr*params.popsize);
     case {'glt1','glt2','glt3','glt4'}
      xobj=30;
      params.evaluation=150000;
      params.H=99;
      params.popsize = 100;
      params.Tm = 20;
      params.Tr = 20;
      %niche = ceil(perTr*params.popsize);
    case {'glt5','glt6'}
      xobj=10;
      params.evaluation=45000;         
      params.H=23;           
      params.popsize = 300;
      params.Tm = 60;
      params.Tr = 60;
      %niche = ceil(perTr*params.popsize);
    case {'jy1','jy2','jy3'}
      xobj=30;
      params.evaluation=100000;         
      params.H=199;           
      params.popsize = 200;
      params.Tm = 20;
      params.Tr = 20;
    case {'jy4','jym4','jy5','jy6'}
      xobj=30;
      params.evaluation=150000;         
      params.H=23;           
      params.popsize = 300;
      params.Tm = 30;
      params.Tr = 30;
     case {'convexdtlz2'}
      xobj=10;
      params.evaluation=150000;
      params.H=23;
      params.popsize = 300;
      params.Tm = 30;
      params.Tr = 30;    
      case {'kno1','pol'}
      xobj=2;
      params.evaluation=100000;         
      params.H=199;           
      params.popsize = 200;
      params.Tm = 20;
      params.Tr = 20;
      %niche = ceil(perTr*params.popsize);
    case {'mop1','mop2','mop3','mop4','mop5'}
      xobj=10;
      params.evaluation=300000;
      params.H=99;            
      params.popsize = 300;
      params.Tm = 30;
      params.Tr = 30;
      %niche = ceil(perTr*params.popsize);
    case {'mop6','mop7'}
      xobj=10;
      params.evaluation=900000;
      params.H=33;            
      params.popsize = 595;
      params.Tm = 60;
      params.Tr = 60;
      %niche = ceil(perTr*params.popsize);
    case {'tec09_f1','tec09_f2','tec09_f3','tec09_f4',...
                'tec09_f5','tec09_f9'}
      xobj=30;
      params.evaluation=150000;
      params.H=99;
      params.popsize = 100;
      params.Tm = 20;
      params.Tr = 20;
      %niche = ceil(perTr*params.popsize);
    case{'tec09_f7','tec09_f8',}
      xobj=10;
      params.evaluation=150000;
      params.H=199;             
      params.popsize = 200;
      params.Tm = 20;
      params.Tr = 20;            
      %niche = ceil(perTr*params.popsize);
    case {'tec09_f6'}
      xobj=10;
      params.evaluation=300000;
      params.H=33;           
      params.popsize = 595;
      params.Tm = 30;
      params.Tr = 30;
      %niche = ceil(perTr*params.popsize);
    case {'f1','f2','f3','f4','f5'...
                'f6','f7'}
      xobj=30;
      params.evaluation=150000;
      params.H=199;
      params.popsize = 200;
      params.Tm = 10;
      params.Tr = 10;
    case {'f8','f9','f10'}
      xobj=10;
      params.evaluation=150000;
      params.H=33;           
      params.popsize = 600;
      params.Tm = 30;
      params.Tr = 30; 
    case {'uf1','uf2','uf3','uf4','uf5','uf6','uf7'}
      xobj=30;
      params.evaluation=300000;
      params.H=599;
      params.popsize = 600;
      params.Tm = 60;
      params.Tr = 60;
    case {'uf8','uf9','uf10'}
      xobj=30;
      params.evaluation=300000;
      params.H=999;
      params.popsize = 1000;
      params.Tm = 100;
      params.Tr = 100;
    otherwise
      warning('Unsupported mop name');
  end
  % handle the parameters passed in from the function directly!
  testmop(testname, xobj);
  if strcmp(methodname,'MOEAD-GR')||strcmp(methodname,'MOEAD-DE')||strcmp(methodname,'MOEAD-NLDE')
     params.perTm=0.1; params.perTr=0.1;
     params.Tm = ceil(params.perTm*params.popsize);     params.Tr = ceil(params.perTr*params.popsize);
%      params.Tm = 20;  params.Tr =5;
     params.adaptmethod={}; params.adaptparams={};
     if strcmp(methodname,'MOEAD-GR')
     params.globupdate = 1;
     params.updatesize = params.Tr;
     elseif  strcmp(methodname,'MOEAD-NLDE')
     params.globupdate = 1;
     params.updatesize = 1; 
     params.NLsize = 5;
     else
     params.globupdate = 0;
     end
     params.genevolve = 0;
  elseif strcmp(methodname,'MOEAD-AGR')||strcmp(methodname,'gMOEAD-AGR')
     params.perTm=0.1; params.adaptmethod='Sigm';    
     switch params.adaptmethod
       case 'Lin'
         params.adaptparams={'perTrmax',0.5};
       case 'Exp'
         params.adaptparams={'perTrmax',0.6,'slope',5};
       case 'Sigm'
         params.adaptparams={'perTrmax',0.4,'slope',20,'center',0.25};
       otherwise
         error('Undefined adaptmethod name');
     end
     params.Tm = ceil(params.perTm*params.popsize);
     params.Tr = agr(params.popsize,params.adaptmethod,params.adaptparams,params.iteration,1);
     params.globupdate = 2;
     params.genevolve = strcmp(methodname,'gMOEAD-AGR');
     params.updatesize =  params.Tr;
  elseif strcmp(methodname(1:8),'MOEAD-MR')
     params.perTm=0.05; params.perTr=0.05;
     params.Tm = ceil(params.perTm*params.popsize); params.Tr = ceil(params.perTr*params.popsize);
     params.adaptmethod={}; params.adaptparams={};
  else
     error('Undefined method name');
  end
  params.iteration = ceil(params.evaluation/params.popsize);

    % R-MOEA/D specific setting.
%     params.dynamic = 1; % weather to use R-MOEA/D or a normal MOEA/D, 1 for R-MOEA/D
%     params.selportion = 5; % the selection percentage of in R-MOEA/D
%     params.decayrate = 0.95; % the decay rate in R-MOEA/D
end

