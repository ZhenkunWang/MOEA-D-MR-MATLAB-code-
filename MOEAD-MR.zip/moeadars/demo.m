function demo()
path('../',path); 
path('../problems',path); 
path('../evolve',path);
global mop params evalCounter itrCounter EP;
tic;
methodname='MOEAD-MR';
maxruntime=30;
testset={'F1','F2','F3','F4','F5','F6','F7','F8','F9'};
for i=1:10
    testname=testset{i};
    params = loadparams(testname,methodname);
    for j=1:maxruntime
    %init
    EP=[];
    evalCounter = 0;
    itrCounter = 1;
    init(mop);
    %evolve
    while ~terminate()
    moead(mop);
    end
    pf     = [EP.objective];
    ps     = [EP.parameter];
    end
 
end
  toc
end
function y =terminate()
    global params evalCounter;
    y = evalCounter>=params.evaluation;
end
