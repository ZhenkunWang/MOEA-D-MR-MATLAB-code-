function init(mop)
%Set up the initial setting for the MOEA/D.
%loading the params.
global subproblems params idealpoint nadirpoint parDim objDim EP boundary itrCounter;  
  idealpoint=ones(mop.od,1)*inf;
%   nadirpoint=ones(mop.od,1)*0;
  parDim = mop.pd;
  objDim = mop.od;
  %initial the subproblem's initital state.
  ideal_size=0.5*params.popsize; nadir_size=0.5*params.popsize;
  subproblems = init_weights(mop.od,ideal_size,nadir_size); 
  inds = randompoint(mop, params.popsize);
  [V, INDS] = arrayfun(@evaluate, repmat(mop, size(inds)), inds, 'UniformOutput', 0);
   v = cell2mat(V);
  idealpoint = min(idealpoint, min(v,[],2)); 
  newinds=cell2mat(INDS);
  EP=EP_update(EP,newinds);
  EPobjectives=[EP.objective];
  nadirpoint = max(EPobjectives,[],2);
%   [extrpos,extrpoints]=find_extrepoints(v);
%   nadirpoint=diag(extrpoints);
%   nadirpoint = max(nadirpoint, max(v,[],2));
% idealpoint = ones(mop.od,1)*1*(itrCounter/params.evaluation-1);
%    allpoint = cell2mat(INDS);
%    subproblems=assignpop(subproblems,allpoint,idealpoint);
  [subproblems.curpoint] = INDS{:}; 
  [subproblems.oldpoint] = INDS{:}; 
%   [subproblems2.curpoint] = INDS{params.popsize+1:2*params.popsize}; 
%   [subproblems2.oldpoint] = INDS{params.popsize+1:2*params.popsize}; 
%   subproblems=[subproblems1,subproblems2];
%%
%   extrempoints=zeros(mop.od,mop.od);
%   exindex=[];
% for bound=1:mop.od
%   bindex=boundary(bound);
%   allobjs=subobjective(subproblems(bindex).weight,  v,  idealpoint,  params.dmethod);   
%   [~,expos]=sort(allobjs);
%   exindex=[exindex;expos];
% % %   extrempoints(bound,:)=(allind(expos).objective)'-idealpoint';
% end
% select=[];
% for i=1:mop.od
% j=1;
% while j<=params.popsize
%     if (sum(exindex(i,j)-exindex(:,j)==0)==1)&&~any(ismember(exindex(i,j), select))
%         select = [select exindex(i,j)];
%         break;
%     else 
%         j=j+1;
%     end
% end  
% end
% extrempoints=v(:,select);
% intercepts=1./((extrempoints'-repmat(idealpoint', mop.od, 1))\ones(mop.od,1));
% nadirpoint = intercepts+idealpoint;
%%
% for bound=1:mop.od
%     bindex=boundary(bound);
%     rep=subproblems(bindex).curpoint;
%     subproblems(bindex).curpoint=subproblems(select(bound)).curpoint;
%     subproblems(bindex).oldpoint=subproblems(bindex).curpoint;
%     subproblems(select(bound)).curpoint=rep;
%     subproblems(select(bound)).oldpoint=subproblems(select(bound)).curpoint;
% end
    clear inds INDS V indcells;
end

function subp=init_weights(objDim,ideal_size,nadir_size)
% init_weights function initialize a pupulation of subproblems structure
% with the generated decomposition weight and the neighborhood relationship.
%initialize direction vectors with unity simplex;
%compute their neighborhood relationship and get their corresponding weight vectors
global params initinformation boundary ;
    
%     subp = [];
%% repair popsize
    [H1,M1]=weightno(ideal_size,objDim);
    [H2,M2]=weightno(nadir_size,objDim);
%     params.popsize=M1+M2;
    params.H=[H1,H2];
        %% repair popsize
    if params.popsize~=M1+M2 %correct the populaiton size
     params.popsize=M1+M2;
     warning('Population size is redefined because of the inconformity');
     if strcmp(methodname,'MOEAD-GR')||strcmp(methodname,'gMOEAD-GR')||strcmp(methodname,'MOEAD-DE')
      params.Tm = ceil(params.perTm*params.popsize);     params.Tr = ceil(params.perTr*params.popsize);
     elseif strcmp(methodname,'MOEAD-AGR')||strcmp(methodname,'gMOEAD-AGR')
      params.Tm = ceil(params.perTm*params.popsize);
      params.Tr = agr(params.popsize,params.adaptmethod,params.adaptparams,params.iteration,1);
     end
    end
    %%
%     H = floor(init_size^(1/(objDim-1)))-2;
%     M = 0;
%     while M<params.popsize
%        H = H+1;
%        M = simplex_weightno(H, 0, objDim); 
%     end
%     if  isempty(params.H)||params.H~=H
%      params.H=H;
%      warning('H is redefined because of the inconformity');       
%     end
%     %to load the parameter from the given file.
%     filename = sprintf('weight/W%uD_%u.dat',objDim,params.popsize);
%     path('../weight',path);
%     if (exist(filename, 'file')&&rand<0)
%     % copy from the exist file. 
%      allws = importdata(filename);
%      W = allws';
%     else
%      W   = zeros(objDim, M);
%      C   = 0;
%      V   = zeros(objDim,1);
%      [W, ~] = simplex_weightset(W, C, V, H, 0, objDim, objDim);
%      W   = W / (H+0.0);
%     end
    %% generate direction vectors
     W1   = zeros(objDim, M1); W2   = zeros(objDim, M2); 
     C   = 0;
     V   = zeros(objDim,1);
     [W1, ~] = simplex_weightset(W1, C, V, H1, 0, objDim, objDim);
     [W2, ~] = simplex_weightset(W2, C, V, H2, 0, objDim, objDim);
     W1   = W1 / (H1+0.0);     W2   = -W2 / (H2+0.0);
     W1((W1 < 1.0E-5))  = 1.0E-5;      W2((W2 > -1.0E-5))  = -1.0E-5;
     v1  = squareform(pdist(W1'));  v2  = squareform(pdist(W2')); 
     %Set up the neighbourhood.
     [~, Ineighborrelation]= sort(v1);   [~, Nneighborrelation] = sort(v2);
%      mneighborrelations=mat2cell(Ineighborrelation,M,ones(1,M));
     Nneighborrelation=Nneighborrelation+M1;
     neighborrelations=[Ineighborrelation,Nneighborrelation];
     Idirvectors=W1;   Ndirvectors=W2;
%     Ndirvectors=W(:,i)-ones(size(dirvectors(:,i)));
%     Ndirvectors((Ndirvectors > -1.0E-5))  = -1.0E-5;
%      Ndirvectors=-W;
     dirvectors=[Idirvectors,Ndirvectors];
     [~,pos]=max(dirvectors,[],2);
     boundary=pos';%
    if  strcmp(params.dmethod,'te')
     weight=(1./dirvectors)./repmat(sum(1./dirvectors),[objDim 1]);
    else
     weight=dirvectors;
    end
    p=get_structure('subproblem');
    subp=repmat(p,1,params.popsize);
    Tmcells=repmat(num2cell(params.Tm),1,params.popsize);
    [subp.Tm] = Tmcells{:};
    Trcells=repmat(num2cell(params.Tr),1,params.popsize);
    [subp.Tr] = Trcells{:};
%     subp2=subp1;
    Wcells = mat2cell(weight(:,1:params.popsize), objDim, ones(1, params.popsize));
    [subp.weight] = Wcells{:};
%     Wcells2 = mat2cell(weight(:,params.popsize+1:2*params.popsize), objDim, ones(1, params.popsize));
%     [subp2.weight] = Wcells2{:};
    initinformation.Ndirvectors=Ndirvectors;
    initinformation.Idirvectors=Idirvectors;
    initinformation.neighborrelations=neighborrelations;
    clear H M W Wcells Tmcells Trcells p Idirvectors Idirvectors dirvectors weight Ineighborrelation Nneighborrelation neighborrelations;
end
function [H,M]=weightno(init_size,objDim)
    H = floor(init_size^(1/(objDim-1)))-2;
    M = 0;
    while M<init_size
       H = H+1;
       M = simplex_weightno(H, 0, objDim); 
    end
end
function M = simplex_weightno(unit, sum, dim)

M = 0;

if dim == 1
    M = 1; 
    return;
end

for i=0:1:(unit - sum)
    M = M + simplex_weightno(unit, sum+i, dim-1);
end

end
function [w, c] =simplex_weightset(w, c, v, unit, sum, objdim, dim)

if dim == objdim
    v = zeros(objdim, 1);
end

if dim == 1
    c       = c+1;
    v(1)    = unit-sum;
    w(:,c)  = v;
    return;
end

for i=0:1:(unit - sum)
    v(dim)  = i;
    [w, c]  = simplex_weightset(w, c, v, unit, sum+i, objdim, dim-1);
end

end