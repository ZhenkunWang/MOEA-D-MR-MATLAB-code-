function inputparams(methodname,varargin)
global params;
 % it has priority higher than the default values.
 Tchange=0;
  while length(varargin)>=2
    prop = varargin{1};
    val= varargin{2};
    varargin=varargin(3:end);
    switch prop
      case 'seed'
        params.seed=val;
      case 'dmethod'
        params.dmethod=val;
      case 'F'
        params.F=val;
      case 'CR'
        params.CR=val;                
      case 'evaluation'
        params.evaluation=val;
      case 'H'
        params.H=val;
      case 'popsize'
        params.popsize=val;
        Tchange=1;
      case 'Tm'
        params.Tm=val;
      case 'Tr'
        params.Tr=val;
      case 'perTm'
        params.perTm=val;
        Tchange=1;
      case 'perTr'
        params.perTr=val; 
        Tchange=1;
      case 'adaptmethod'
        if strcmp(methodname,'MOEAD-AGR')||strcmp(methodname,'gMOEAD-AGR')
        params.adaptmethod=val;
        Tchange=1;
        else
        error('Unsupported parameter name');
        end
      case 'adaptparams'
        if strcmp(methodname,'MOEAD-AGR')||strcmp(methodname,'gMOEAD-AGR')
        params.adaptparams=val;
        Tchange=1;
        else
        error('Unsupported parameter name');
        end
      case 'neighbormating'
        params.neighbormating=val; 
      case 'updatesize'
        params.updatesize = val;
%     case 'dynamic'
%       params.dynamic=val;
      otherwise
        warning('Unsupported parameter name');
    end
  end
  if Tchange %weather to use the proportion of population size or a given number as the neighborhoond size, 1 for proportion
    if strcmp(methodname,'MOEAD-GR')||strcmp(methodname,'MOEAD-DE')
      params.Tm = ceil(params.perTm*params.popsize);     params.Tr = ceil(params.perTr*params.popsize);
    elseif strcmp(methodname,'MOEAD-AGR')||strcmp(methodname,'gMOEAD-AGR')
      params.Tm = ceil(params.perTm*params.popsize);
      params.Tr = agr(params.popsize,params.adaptmethod,params.adaptparams,params.iteration,1);
    end
  end
  params.iteration = ceil(params.evaluation/params.popsize);
end
