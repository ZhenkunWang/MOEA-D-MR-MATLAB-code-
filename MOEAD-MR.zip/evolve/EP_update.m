function EP=EP_update(EPa,newinds)
global params;
allinds=[EPa,newinds];
allobjectives=[allinds.objective];
 %% �˵��ظ���
[~,un_all,~]=unique(allobjectives','rows','first');
% objsize=length(un_allobindexs);
un_allindexs=un_all';
un_allobjectives=allobjectives(:,un_allindexs);
%% find nondominated solutions
[NP_exist,NPsize] = ParetoFilter(un_allobjectives);
NP_index=un_allindexs(NP_exist);
if NPsize>params.popsize
    tP=allobjectives(:,NP_index);
    E  = squareform(pdist(tP')); 
    while NPsize>params.popsize
%         SE=[];
        SE=sort(E);
        i=1;candidates=1:NPsize;
        while i<NPsize
%             EC=[];
            EC=SE(i+1,candidates);
            candidates=candidates(EC==min(EC));
%             [aa,bb]=min(EC);dd=find(EC==aa);cc=cc(dd);
            if length(candidates)==1
                deleti=candidates;
                break;
            end
            i=i+1;
        end
        if length(candidates)~=1
            deleti=candidates(1);
        end
        NP_index(deleti)=[];
        E(deleti,:)=[];E(:,deleti)=[];
        NPsize=NPsize-1;
    end    
end
EP=allinds(NP_index); 
end

function [NP_index,NN,ParetoF] = ParetoFilter(F)

% [ParetoF,ParetoX] = ParetoFilter( F, X ) filter the Pareto solutions from
% F and X
%
%     Parameters:
%     X  - data set (X)
%     F  - data set (F)
%     Size - data size to keep
%     Returns:
%     ParetoX   - nondominated solutions (X) 
%     ParetoF   - nondominated solutions (F)
%
[DF,NF]=size(F);
exist   = ones(1,NF);     % exist or not
for i=1:1:NF
    for j=i+1:1:NF
        % Fi dominate Fj
        if(sum(F(:,i) <= F(:,j)) == DF && sum(F(:,i) == F(:,j)) < DF)
            exist(j) = 0;
        % Fj dominate Fi
        elseif(sum(F(:,i) >= F(:,j)) == DF && sum(F(:,i) == F(:,j)) < DF)
            exist(i) = 0;
        end        
    end
end

NN = sum(exist);
NP_index=find(exist==1);
%%
ParetoF = F(:,NP_index);
%%
% % ParetoX = ones(size(X,1),NN);
% k = 1;
% for i=1:1:NF
%     if(exist(i)>0)
% %         ParetoX(:,k) = X(:,i);
%         ParetoF(:,k) = F(:,i);
%         k = k + 1;
%     end
% end
end