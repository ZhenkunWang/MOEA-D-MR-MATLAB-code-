function moead(mop)
%MOEAD run moea/d algorithms for the given mop.
% MOP could be obtained by function 'testmop.m'.
% the controlling parameter can be passed in by varargin, the folliwing
% parameters are defined in here. More other parameters can be passed by
% modify loadparams.m problem by problem.
%   seed: the random seed.
%   popsize: The subproblem's size.
%   niche: the neighboursize, must less then the popsize.
%   evaluation: the total evaluation of the moead algorithms before finish.
%   dynamic: whether to use dynamic resource allocation.
%   selportion: the selection portion for the dynamic resource allocation

    global itrCounter;
    evolve(mop); % one generation of evaluation.
    itrCounter=itrCounter+1;
end

% The evoluation setp in MOEA/D
function evolve(mop)
  global params subproblems idealpoint nadirpoint;
  if (params.dynamic)
    selindex = util_select();
  else
   selindex = 1:length(subproblems);
   selindex =random_shuffle(selindex);
  end
  for i=1:length(selindex)
    index = selindex(i);
    r = rand;
    useneighbour = r < params.neighbormating;
    ind = genetic_op(index,mop.domain,useneighbour);
    inds(1,i)=ind;
  end
  [V, INDS] = arrayfun(@evaluate, repmat(mop, size(inds)), inds, 'UniformOutput', 0);
  v = cell2mat(V);
  oldinds=[subproblems.curpoint];
  oldinds=num2cell(oldinds, 1);
  indiv=get_structure('individual');
  allind = repmat(indiv, 1,length(oldinds)+length(INDS));
  allind(1:length(oldinds))=cell2mat(oldinds);
  allind(length(oldinds)+1:length(oldinds)+length(INDS))=cell2mat(INDS);
  idealpoint = min(idealpoint, min(v,[],2));

 %%
 [extrpos,extrpoints]=find_extrepoints([allind.objective]);
  nadirpoint=diag(extrpoints);
  genupdate(allind);
clear inds INDS oldinds V v indiv allind;
end
% update the index's neighbour with the given individual.
% index is the subproblem's index in the main population.
% ind is the individual structure.
% updatenieghbour is a bool determine whether the neighbourhood of index, or the whole population should be updated.
% this procedure is also governed by a parameter from params: params.updatenb, which determine how many subproblem
% should be updated at most by this new individual.

function genupdate(allind)
global subproblems idealpoint nadirpoint params mop initinformation EP;
 Idirvectors=initinformation.Idirvectors;
 Ndirvectors=initinformation.Ndirvectors;
 allobjectives=[allind.objective];
 %% �˵��ظ���
 [~,un_allobindexs,~]=unique( allobjectives','rows','first');
 objsize=length(un_allobindexs);  
 un_allobjectives=allobjectives(:,un_allobindexs');
 %% �������ο����һ��
 intercepts=nadirpoint-idealpoint;
 norm_objvectors1=(un_allobjectives-repmat(idealpoint, 1,objsize))./repmat(intercepts, 1, objsize);
 norm_objvectors2=(un_allobjectives-repmat(nadirpoint, 1,objsize))./repmat(intercepts, 1, objsize);
 %% �趨���������С
 if mop.od==2
Tr=5;
 else
Tr=10;
 end
 %% Ϊÿһ����ƥ��Direction vectors
 cand=cell(1,params.popsize); 
 Idirs_long=size(Idirvectors,2);  Ndirs_long=size(Ndirvectors,2); 
 distmatrix=zeros(objsize,params.popsize);
 for i=1:objsize
     distance1=sqrt(sum((repmat(norm_objvectors1(:,i),1,Idirs_long)-repmat(((norm_objvectors1(:,i)'*Idirvectors)./sum(Idirvectors.^2)),mop.od,1).*Idirvectors).^2));
     distance2=sqrt(sum((repmat(norm_objvectors2(:,i),1,Ndirs_long)-repmat(((norm_objvectors2(:,i)'*Ndirvectors)./sum(Ndirvectors.^2)),mop.od,1).*Ndirvectors).^2));
     distance=[distance1,distance2];
     distmatrix(i,:)=distance;
     [~,pos]=sort(distance); index=pos(1:Tr);
     for associate=1:Tr
        cand{index(associate)}=[cand{index(associate)},i];
     end
 end
 %%
subindexs=1:params.popsize; 
soluindexs=1:length(un_allobindexs); 
deletsolu=zeros(length(un_allobindexs),1);
deletsub=zeros(1,params.popsize);
  for j=1:params.popsize
     candindexs=cand{j};
     if  ~isempty(candindexs)&&j<=Idirs_long
     candsubs=subobjective(subproblems(j).weight, norm_objvectors1(:,candindexs),  zeros(mop.od,1), params.dmethod);
     old_sub=subobjective( subproblems(j).weight,  (subproblems(j).curpoint.objective-idealpoint)./intercepts,  zeros(mop.od,1),  params.dmethod);
     [new_sub,poscand]=min(candsubs);
     orindex=un_allobindexs(candindexs(poscand));
       if new_sub<old_sub
          subproblems(j).curpoint=allind(orindex); 
      deletsub(j)=1;
      deletsolu(candindexs(poscand))=1;
       end
     elseif ~isempty(candindexs)&&j>Idirs_long
     candsubs=subobjective(subproblems(j).weight, norm_objvectors1(:,candindexs),  ones(mop.od,1), params.dmethod);
     old_sub=subobjective( subproblems(j).weight, (subproblems(j).curpoint.objective-idealpoint)./intercepts,  ones(mop.od,1),  params.dmethod);
     [new_sub,poscand]=min(candsubs);
     orindex=un_allobindexs(candindexs(poscand));
       if new_sub<old_sub
          subproblems(j).curpoint=allind(orindex); 
      deletsub(j)=1;
      deletsolu(candindexs(poscand))=1;
       end
     end
  end
 soluindexs(deletsolu==1)=[]; 
 subindexs(deletsub==1)=[]; 
 distmatrix(deletsolu==1,:)=[]; 
 distmatrix(:,deletsub==1)=[]; 
 %%
 nonsel=length(subindexs);
 selindex =random_shuffle(subindexs);
 for k=1:nonsel
     subindex=selindex(k);
     orig_subindex=find(subindexs==subindex);
     [val,index]=sort(distmatrix);
     candindexs=soluindexs(index(1:Tr,orig_subindex))';
     if subindex>Idirs_long
     referencepoint=ones(mop.od,1);
     else
     referencepoint=zeros(mop.od,1);
     end
     candsubs=subobjective(subproblems(subindex).weight, norm_objvectors1(:,candindexs),  referencepoint, params.dmethod);
     old_sub=subobjective( subproblems(subindex).weight, (subproblems(subindex).curpoint.objective-idealpoint)./intercepts,  referencepoint,  params.dmethod);
     [new_sub,poscand]=min(candsubs);
     orindex=un_allobindexs(candindexs(poscand));
       if new_sub<old_sub
          subproblems(subindex).curpoint=allind(orindex); 
      distmatrix(:,orig_subindex)=[];
      distmatrix(soluindexs==candindexs(poscand),:)=[];
      subindexs(orig_subindex)=[];
      soluindexs(soluindexs==candindexs(poscand))=[];

       end  
 end
 EP=EP_update(EP,[subproblems.curpoint]);
end
