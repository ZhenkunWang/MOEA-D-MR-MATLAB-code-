function testmop( testname, pdim)
%Get test multi-objective problems from a given name. 
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The test problem will be encapsulated in a structure,
%   which can be obtained by function get_structure('testmop'). 
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional dimension parameters.
global mop;
mop=struct('name',[],'od',[],'pd',[],'domain',[],'func',[]);
    switch lower(testname)
        case 'kno1'
            mop=kno1(mop);
        case 'pol'
            mop=pol(mop);
        case 'convexdtlz2'
            odim=3;
            mop=convexdtlz2(mop,pdim,odim);
        case {'zdt1','zdt2','zdt3','zdt4','zdt5','zdt6'}
            mop=zdt(testname,pdim);
        case {'dtlz1','dtlz2','dtlz3','dtlz4','dtlz5','dtlz6','dtlz7'}
            odim=3;
            mop=dtlz(testname,pdim,odim);
        case {'wfg1','wfg2','wfg3','wfg4','wfg5','wfg6','wfg7','wfg8','wfg9'}
            odim=2; k=odim-1;
            mop=wfg(testname,pdim,odim,k);
        case {'zzj_f1','zzj_f2','zzj_f3','zzj_f4','zzj_f5','zzj_f6','zzj_f7','zzj_f8','zzj_f9','zzj_f10'}
            mop=zzj( testname, pdim);        
        case {'tec09_f1','tec09_f2','tec09_f3','tec09_f4','tec09_f5','tec09_f6','tec09_f7','tec09_f8','tec09_f9'}
            mop=tec09( testname, pdim );
        case {'f1','f2','f3','f4','f5','f6','f7','f8','f9','f10'}
            mop=f( testname, pdim );
        case {'mop1','mop2','mop3','mop4','mop5','mop6','mop7'}
            mop=MOP(testname,pdim);
        case {'glt1','glt2','glt3','glt4','glt5','glt6'}
            mop=glt(testname,pdim);
        case {'jy1','jy2','jy3','jy4','jy5','jy6','jym4'}
            mop=jy(testname,pdim);
        case {'uf1', 'uf2','uf3','uf4','uf5','uf6','uf7'}
            mop=cecproblems(mop, testname, pdim);
            mop.od=2;    
        case {'uf8','uf9','uf10'}
            mop=cecproblems(mop, testname, pdim);
            mop.od=3;   
        case {'r2_dtlz2_m5', 'r3_dtlz3_m5', 'wfg1_m5'}
            mop=cecproblems2(mop, testname, pdim); 
        otherwise 
            error('Undefined test problem name'); 
    end    
end
%cec09 UF1 - UF10
function p=cecproblems(p, testname,dim)
 p.name=upper(testname);
 p.pd=dim;
 
 p.domain=xboundary(upper(testname),dim);
 %p.domain = [zeros(dim,1),ones(dim,1)];
 p.func=cec09(upper(testname));
end

%cec09 UF11 - UF13
function p=cecproblems2(p, testname,dim)
 p.name=upper(testname);
 p.pd=dim;
 p.od=2;
 
 p.domain=xboundary(upper(testname),dim);
 %p.domain = [zeros(dim,1),ones(dim,1)];
 p.func=cec09m(upper(testname));
end
%%
%KNO1 function generator
function p=kno1(p)
 p.name='KNO1';
 p.od = 2;      % dimension of objectives
 p.pd = 2;      % dimension of x
 p.domain= [0 3;0 3];   % search domain
 p.func = @evaluate;
 
    %KNO1 evaluation function.
    function y = evaluate(x)
      y=zeros(2,1);
	  c = x(1)+x(2);
	  %f = 9-(3*sin(2.5*c^0.5) + 3*sin(4*c) + 5 *sin(2*c+2));
      f = 9-(3*sin(2.5*c^2) + 3*sin(4*c) + 5 *sin(2*c+2));
	  g = (pi/2.0)*(x(1)-x(2)+3.0)/6.0;
	  y(1)= 20-(f*cos(g));
	  y(2)= 20-(f*sin(g)); 
    end
end
function p=pol(p)
 p.name='POL';
 p.od = 2;      % dimension of objectives
 p.pd = 2;      % dimension of x
 p.domain= [-pi pi;-pi pi];   % search domain
 p.func = @evaluate;
 
    %KNO1 evaluation function.
    function y = evaluate(x)         
      y=zeros(2,1);
      A1=0.5*sin(1)-2*cos(1)+sin(2)-1.5*cos(2);
      A2=1.5*sin(1)-cos(1)+2*sin(2)-0.5*cos(2);
      B1=0.5*sin(x(1))-2*cos(x(1))+sin(x(2))-1.5*cos(x(2));
      B2=1.5*sin(x(1))-cos(x(1))+2*sin(x(2))-0.5*cos(x(2));        
	  y(1)= 1+(A1-B1)^2+(A2-B2)^2;
	  y(2)= (x(1)+3)^2+(x(2)+1)^2; 
    end
end
%%
function p =convexdtlz2(p,pdim,odim)
 p.name     = 'ConvexDTLZ2';
 p.pd       = pdim;% default pd=30
 p.od       = odim;
 %p.pf       = load('C_DTLZ2.pf');
 p.domain   = [zeros(1,pdim); ones(1,pdim)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    N   = pdim;
    G=sum((X(3:N)-0.5).^2);
    F   = zeros(1,3);
    F(1)= ((1+G)*cos(0.5*pi*X(1))*cos(0.5*pi*X(2)))^4;
    F(2)= ((1+G)*cos(0.5*pi*X(1))*sin(0.5*pi*X(2)))^4;
    F(3)= ((1+G)*sin(0.5*pi*X(1)))^4;
end
end