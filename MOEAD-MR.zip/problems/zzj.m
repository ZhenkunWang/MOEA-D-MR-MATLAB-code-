function mop=zzj( testname, dimension)
    mop=struct('name',[],'od',[],'pd',[],'domain',[],'func',[]);  
    switch lower(testname)          
        case 'zzj_f1'
            mop=zzj_f1(mop, dimension);
        case 'zzj_f2'
            mop=zzj_f2(mop, dimension);
        case 'zzj_f3'
            mop=zzj_f3(mop, dimension);
        case 'zzj_f4'
            mop=zzj_f4(mop, dimension);
        case 'zzj_f5'
            mop=zzj_f5(mop, dimension);     
        case 'zzj_f6'
            mop=zzj_f6(mop, dimension); 
        case 'zzj_f7'
            mop=zzj_f7(mop, dimension); 
        case 'zzj_f8'
            mop=zzj_f8(mop, dimension); 
        case 'zzj_f9'
            mop=zzj_f9(mop, dimension); 
        case 'zzj_f10'
            mop=zzj_f10(mop, dimension);                        
        otherwise 
            error('Undefined test problem name');                
    end 
end
function p = zzj_f1(p,dim)
 p.name     = 'ZZJ_F1';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:);
    G   = 1.0 + 9.0*(X1 - X(1))'*(X1 - X(1))/(N-1.0);

    F(1)= X(1);
    F(2)= G*(1.0-sqrt(F(1)/G));
end
end

%%
function p = zzj_f2(p,dim)
 p.name     = 'ZZJ_F2';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:);
    G   = 1.0 + 9.0*(X1 - X(1))'*(X1 - X(1))/(N-1.0);

    F(1)= X(1);
    F(2)= G*(1.0-(F(1)/G)^2.0);
end
end

%%
function p = zzj_f3(p,dim)
 p.name     = 'ZZJ_F3';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:);
    G   = 1.0 + 9.0*((X1 - X(1))'*(X1 - X(1))/9.0)^0.25;

    F(1)= 1.0-exp(-4.0*X(1))*sin(6.0*pi*X(1)).^6.0;
    F(2)= G*(1.0-(F(1)/G)^2.0);
end
end

%%
function p = zzj_f4(p,dim)
 p.name     = 'ZZJ_F4';
 p.pd       = dim;
 p.od       = 3;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(3,1);
    N   = size(X,1);
    X1  = X(3:N,:);
    G   = (X1 - X(1))'*(X1 - X(1));
    
    F(1) = cos(0.5*pi*X(1))*cos(0.5*pi*X(2))*(1.0+G);
    F(2) = cos(0.5*pi*X(1))*sin(0.5*pi*X(2))*(1.0+G);    
    F(3) = sin(0.5*pi*X(1))*(1.0+G);
end
end

%%
function p = zzj_f5(p,dim)
 p.name     = 'ZZJ_F5';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:).^2.0;
    G   = 1.0 + 9.0*(X1 - X(1))'*(X1 - X(1))/(N-1.0);

    F(1)= X(1);
    F(2)= G*(1.0-sqrt(F(1)/G));
end
end

%%
function p = zzj_f6(p,dim)
 p.name     = 'ZZJ_F6';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:).^2.0;
    G   = 1.0 + 9.0*(X1 - X(1))'*(X1 - X(1))/(N-1.0);

    F(1)= X(1);
    F(2)= G*(1.0-(F(1)/G)^2.0);
end
end

%%
function p = zzj_f7(p,dim)
 p.name     = 'ZZJ_F7';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = X(2:N,:).^2.0;
    G   = 1.0 + 9.0*((X1 - X(1))'*(X1 - X(1))/9.0)^0.25;

    F(1)= 1.0-exp(-4.0*X(1))*sin(6.0*pi*X(1)).^6.0;
    F(2)= G*(1.0-(F(1)/G)^2.0);
end
end

%%
function p = zzj_f8(p,dim)
 p.name     = 'ZZJ_F8';
 p.pd       = dim;
 p.od       = 3;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(3,1);
    N   = size(X,1);
    X1  = X(3:N,:).^2.0;
    G   = (X1 - X(1))'*(X1 - X(1));
    
    F(1) = cos(0.5*pi*X(1))*cos(0.5*pi*X(2))*(1.0+G);
    F(2) = cos(0.5*pi*X(1))*sin(0.5*pi*X(2))*(1.0+G);    
    F(3) = sin(0.5*pi*X(1))*(1.0+G);
end
end

%%
function p = zzj_f9(p,dim)
 p.name     = 'ZZJ_F9';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = (X(2:N,:)*10.0).^2.0;
    G   = 2.0 + (X1 - X(1))'*(X1 - X(1))/(4000.0)+ prod(cos((X1-X(1))./((1:N-1)'.^0.5)));

    F(1)= X(1);
    F(2)= G*(1.0-sqrt(F(1)/G));
end
end

%%
function p = zzj_f10(p,dim)
 p.name     = 'ZZJ_F10';
 p.pd       = dim;
 p.od       = 2;
 p.domain   = [zeros(dim,1) ones(dim,1)];
 p.func     = @evaluate;
 
function F = evaluate(X)
    F   = zeros(2,1);
    N   = size(X,1);
    X1  = (X(2:N,:)*10.0).^2.0;
    G   = 1.0 + 10.0*(N-1) + (X1 - X(1))'*(X1 - X(1))/(4000.0)- 10.0*sum(cos(2*pi*(X1-X(1))));

    F(1)= X(1);
    F(2)= G*(1.0-sqrt(F(1)/G));
end
end
